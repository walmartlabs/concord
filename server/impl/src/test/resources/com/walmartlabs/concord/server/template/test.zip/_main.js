({
    entryPoint: "main",
    arguments: {
        ansibleParams: _input
    }
});
